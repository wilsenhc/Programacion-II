#ifndef _COLA_HPP_
#define _COLA_HPP_
#include "Nodo.hpp"
#include <iostream>

template<class Item>
class Cola
{
    private:
        int length;
        Nodo<Item> *primero;
        Nodo<Item> *ultimo;

    public:
        Cola();
        Cola(const Cola<Item>&);
        ~Cola();

        int longitud();
        bool esVacia();
        void encolar(Item);
        void desencolar();
        Item frente();
        void vaciar();
        void imprimir();
};

/**
 * Constructor de Cola.
 * Construye una Cola vacia.
 * @constructs Cola
 * */
template<class Item>
Cola<Item>::Cola()
    : length( 0 ), primero( NULL ), ultimo( NULL ) { }

/**
 * Constructor Copia.
 * @constructs Cola
 * */
template<class Item>
Cola<Item>::Cola(const Cola<Item>& in)
{
    if (in.primero != NULL)
    {
        primero = new Nodo<Item>();
        primero->setInfo(in.primero->getInfo());
        Nodo<Item> *inPivot = in.primero->getSig();
        Nodo<Item> *thisPivot = this->primero;
        Nodo<Item> *add;

        while (inPivot != NULL)
        {
            add = new Nodo<Item>();
            add->setInfo(inPivot->getInfo());
            thisPivot->setSig(add);
            thisPivot = thisPivot->getSig();
            inPivot = inPivot->getSig();
        }
        ultimo = add;
    }
    this->length = in.length;
}

/**
 * Destructor de Cola.
 * */
template<class Item>
Cola<Item>::~Cola()
{
    if(!esVacia())
        this->vaciar();
}

/**
 * Muestra longitud de la cola
 * @returns {int} Longitud de la cola
 * */
template<class Item>
int Cola<Item>::longitud()
{
    return length;
}

/**
 * Indica si la lista esta vacia.
 * @returns {bool} TRUE sí esta vacia.
 * */
template<class Item>
bool Cola<Item>::esVacia()
{
    return length == 0;
}

/**
 * Encolar.
 * @param {Item} e - Item a encolar.
 * */
template<class Item>
void Cola<Item>::encolar(Item e)
{
    Nodo<Item> *nuevo = new Nodo<Item>();
    nuevo->setInfo(e);

    if (esVacia())
    {
        primero = nuevo;
        ultimo = nuevo;
    }
    else
    {
        ultimo->setSig(nuevo);
        ultimo = nuevo;
    }

    length++;
}

template<class Item>
void Cola<Item>::desencolar()
{
    if (!esVacia())
    {
		Nodo<Item> *aux = primero;
		length--;
		if (length != 0)
			primero = primero->getSig();
		else
		{
			primero = NULL;
			ultimo = NULL;
		}
		delete aux;
	}
}

/**
 * Muestra el elemento del frente.
 * @function
 * @returns {Item} Elemento del frente.
 * */
template<class Item>
Item Cola<Item>::frente()
{
    if(!esVacia())
        return primero->getInfo();
}

/**
 * Vaciar Cola.
 * */
template<class Item>
void Cola<Item>::vaciar()
{
    if (!esVacia())
    {
        Nodo<Item> *actual, *next;
        actual = primero;
        next = actual->getSig();

        for (int i = 1; i < length; i++)
        {
            delete actual;
            actual = next;
            next = actual->getSig();
        }
        delete actual;

        length = 0;
        primero = NULL;
        ultimo = NULL;
    }
}

/**
 * Imprimir cola.
 * Solo para fines de debug.
 * @deprecated
 * */
template<class Item>
void Cola<Item>::imprimir()
{
    if  (length == 0)
        std::cout << "Cola vacia" << std::endl;
    else
    {
        Nodo<Item> *act = primero;
        for (int i = 0; i < length; i++, act = act->getSig())
            std::cout << act->getInfo() << " ";

        std::cout << std::endl;
    }

}

#endif
